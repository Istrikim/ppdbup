<?php

if(isset($_POST['submit'])){
        $userid = $_POST['id'];
       
        $kartukeluarga = 'kartukeluarga'.$nisn;
        $rapor = 'rapor'.$nisn;
        $akte = 'akte'.$nisn;
        $ijazahdepan = 'ijazahdpn_'.$nisn;
        $ijazahbelakang = 'ijazahblkg_'.$nisn;

        //perihal gambar
        $nama_file_kk = $_FILES['kartukeluarga']['name'];
        $nama_file_rapor = $_FILES['rapor']['name'];
        $nama_file_akte = $_FILES['akte']['name'];
        $nama_file_idpn = $_FILES['scanijazahdepan']['name'];
        $nama_file_iblkg = $_FILES['scanijazahbelakang']['name'];
        $ext1 = pathinfo($nama_file_kk, PATHINFO_EXTENSION);
        $ext1 = pathinfo($nama_file_rapor, PATHINFO_EXTENSION);
        $ext1 = pathinfo($nama_file_akte, PATHINFO_EXTENSION);
        $ext2 = pathinfo($nama_file_idpn, PATHINFO_EXTENSION);
        $ext3 = pathinfo($nama_file_iblkg, PATHINFO_EXTENSION);
        $ukuran_file_kk = $_FILES['kartukeluarga']['size'];
        $ukuran_file_rapor = $_FILES['rapor']['size'];
        $ukuran_file_akte = $_FILES['akte']['size'];
        $ukuran_file_idpn = $_FILES['scanijazahdepan']['size'];
        $ukuran_file_iblkg = $_FILES['scanijazahbelakang']['size'];
        $ukurantotal = $ukuran_file_kk + $ukuran_file_rapor + $ukuran_file_akte + $ukuran_file_idpn + $ukuran_file_iblkg;
        $tipe_file = $_FILES['kk']['type'];
        $tmp_file = $_FILES['rapor']['tmp_name'];
        $tmp_file = $_FILES['akte']['tmp_name'];
        $tmp_file2 = $_FILES['scanijazahdepan']['tmp_name'];
        $tmp_file3 = $_FILES['scanijazahbelakang']['tmp_name'];
        $path_kk= "images/kk/".$kk.'.'.$ext1;
        $path_rapor= "images/rapor/".$rapor.'.'.$ext2;
        $path_akte= "images/akte/".$akte.'.'.$ext3;
        $path_idpn = "images/ijazahdepan/".$ijazahdepan.'.'.$ext4;
        $path_iblkg = "images/ijazahbelakang/".$ijazahbelakang.'.'.$ext5;


        if($tipe_file == "image/jpeg" || $tipe_file == "image/png"){
          if($ukurantotal <= 1600000){ 
            $upload = move_uploaded_file($tmp_file,$path_kk);
            $upload2 = move_uploaded_file($tmp_file2,$path_rapor);
            $upload2 = move_uploaded_file($tmp_file3,$path_akte);
            $upload2 = move_uploaded_file($tmp_file4,$path_idpn);
            $upload3 = move_uploaded_file($tmp_file5,$path_iblkg);
            if($upload&&$upload2&&$upload3&&$upload4&&$upload5){ 
            
                $submitdata = mysqli_query($conn,"insert into userdata (userid, kk, rapor, akte, scanijazahdepan, scanijazahbelakang) 
                values('$userid','$path_kk', '$path_rapor', '$path_akte','$path_idpn','$path_iblkg')");
                
              if($submitdata){ 

                //berhasil bikin
                echo " <div class='alert alert-success'>
                        Berhasil submit data.
                    </div>
                    <meta http-equiv='refresh' content='2; url= persyaratan.php'/>  ";  

              }else{

                echo "<div class='alert alert-warning'>
                        Gagal submit data. Silakan coba lagi nanti.
                    </div>
                    <meta http-equiv='refresh' content='3; url= persyaratan.php'/> ";
                }
            }else{
              // Jika gambar gagal diupload, Lakukan :
              echo "Sorry, there's a problem while uploading the file.";
              echo "<br><meta http-equiv='refresh' content='5; URL=persyaratan.php'> You will be redirected to the form in 5 seconds";
            }
          }else{
            // Jika ukuran file lebih dari 1MB, lakukan :
            echo "Sorry, the file size is not allowed to more than 1,5mb";
            echo "<br><meta http-equiv='refresh' content='5; URL=persyaratan.php'> You will be redirected to the form in 5 seconds";
          }
        }else{
          // Jika tipe file yang diupload bukan JPG / JPEG / PNG, lakukan :
          echo "Sorry, the image format should be JPG/PNG.";
          echo "<br><meta http-equiv='refresh' content='5; URL=persyaratan.php'> You will be redirected to the form in 5 seconds";
        }

    };





    
//get timezone jkt
date_default_timezone_set("Asia/Bangkok");
$today = date("Y-m-d"); //now

    //kalau konfirmasi
    if(isset($_POST['ok'])){
      $id = $_POST['id'];
      $updateaja = mysqli_query($conn,"update userdata set status='Verified', tglkonfirmasi='$today' where userid='$id'");

      if($updateaja){
        //berhasil bikin
          echo " <div class='alert alert-success'>
          Berhasil submit data.
      </div>
      <meta http-equiv='refresh' content='1; url= persyaratan.php'/>  ";  
      } else {
        echo "<div class='alert alert-warning'>
              Gagal submit data. Silakan coba lagi nanti.
          </div>
          <meta http-equiv='refresh' content='3; url= persyaratan.php'/> ";
      }
    };

?>